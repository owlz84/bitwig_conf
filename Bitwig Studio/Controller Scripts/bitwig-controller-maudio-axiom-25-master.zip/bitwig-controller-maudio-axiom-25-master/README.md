Bitwig controller script for the M-Audio Axiom 25

